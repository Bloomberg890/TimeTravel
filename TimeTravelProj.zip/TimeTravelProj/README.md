
  # Time Travel WebPortal UI (Community)

  This is a code bundle for Time Travel WebPortal UI (Community). The original project is available at https://www.figma.com/design/HPSbZ6dNSeGKxdFVeUOZko/Time-Travel-WebPortal-UI--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  